# ExtrasNode node for ComfyUI

Custom nodes for ComfyUI

> Includes:
> **PreviewTextNode** - The node displays the input text
